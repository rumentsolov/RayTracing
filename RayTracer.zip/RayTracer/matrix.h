#ifndef MATRIX_H
#define MATRIX_H

#include "publics.h"

class Matrix{

public:
    std::string** str;
    
    Matrix(){
        str = new std::string*[imageX]; // Allocates memory for coluns

        for (int x = 0; x < imageX; x++)
            str[x] = new std::string[imageY]; //  Allocates memory for rows

        for (int y = 0; y < imageY; y++){
            for (int x = 0; x < imageX; x++) {
            //str[x][y] = "--- ";
            //str[i][j] = "000 000 000  ";
            str[x][y] = "--- --- --- ";
            }
        }
    }


        void print(){
            for (int y = 0; y < imageY; y++){
                for (int x = 0; x < imageX; x++) {
                    std::cout << str[x][y];
                }
            std::cout << std::endl;
            }

    
        }

        


        void draw(const Point start(startX ,startY), const Point end(endX, endY) const std::string & put){
                    for (int y = startY; y < endY; y++) 
                        for (int x = startX; x < endX; x++) 
                            str[x][y] = put;
        }
        
        void record(){

            std::ofstream ppmFS(fileName, std::ios::out | std::ios::binary);

            ppmFS << "P3\n" << imageX << " " << imageY << "\n" << maxColorComponent << "\n";
            
            for (int y = 0; y < imageY; y++)
                for (int x = 0; x < imageX; x++) { {
                    ppmFS<< str[x][y];
                }
            ppmFS << "\n";
            }
            
            ppmFS.close();
        }
      
};

#endif