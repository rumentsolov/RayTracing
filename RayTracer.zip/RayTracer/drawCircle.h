#ifndef DRAW_CIRCLE_H
#define DRAW_CIRCLE_H

#include "publics.h"
#include "matrix.h"


void drawCircle(Matrix &m){

    imageCenterX = imageX /2;
    imageCenterY = imageY /2;

    

    endX = imageCenterX + radius;
    endY = imageCenterY + radius;

    std::string put = "255 255 255  ";

    //m.draw(imageCenterX, imageCenterY , imageCenterX + 1 , endY, put);

    Point Center(imageCenterX , imageCenterY);
    const double PI = 3.14159;

for (double angle=0; angle<=2*PI; angle+=1)//0.001
     //This will have the coordinates  you want to draw a point at
     Point( Center.x + radius*cos( angle ), Center.y + radius*sin( angle ) );

}

#endif //!DRAW_CIRCLE_H